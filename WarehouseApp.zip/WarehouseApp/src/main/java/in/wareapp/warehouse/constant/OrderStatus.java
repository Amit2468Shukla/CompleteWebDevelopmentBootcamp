package in.wareapp.warehouse.constant;

public enum OrderStatus {

	OPEN, PICKING, ORDERED, INVOICED, RECEIVED
}
