package in.wareapp.warehouse.exception;

public class WhUserTypeNotFoundException extends RuntimeException {
	
	private static final long serialVersionUID = -5494637085915231543L;

	public WhUserTypeNotFoundException() {
		super();
	}

	public WhUserTypeNotFoundException(String message) {
		super(message);
	}
}
