package in.wareapp.warehouse.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import in.wareapp.warehouse.model.Grn;

public interface GrnRepository extends JpaRepository<Grn, Integer> {

}
