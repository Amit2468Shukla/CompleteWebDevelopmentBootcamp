package in.wareapp.warehouse.setup;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import in.wareapp.warehouse.model.User;
import in.wareapp.warehouse.service.IUserService;

@Component
public class SetupAdmin implements CommandLineRunner {
	@Autowired
	private IUserService service;
	
	@Override
	public void run(String... args) throws Exception {
		User user = new User();
		user.setName("Amit");
		user.setEmail("uccamit727738@gmail.com");
		user.setPwd("Amit@1511219");
		user.setActive(true);
		//user.setRoles(List.of("ADMIN","APPUSER"));
		if(service.findByEmail(user.getEmail()).isEmpty()) {
			service.saveUser(user);
		}
	}

}
