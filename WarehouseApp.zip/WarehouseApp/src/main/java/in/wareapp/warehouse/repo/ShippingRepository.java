package in.wareapp.warehouse.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import in.wareapp.warehouse.model.Shipping;

public interface ShippingRepository extends JpaRepository<Shipping, Integer> {

}
