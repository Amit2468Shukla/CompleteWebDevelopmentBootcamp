package in.wareapp.warehouse.service;

import java.util.List;

import in.wareapp.warehouse.model.Grn;
import in.wareapp.warehouse.model.GrnDtl;

public interface IGrnService {

	public Integer saveGrn(Grn grn);
	public Grn getOneGrn(Integer id);
	public List<Grn> getAllGrns();
	
	public Integer saveGrnDtl(GrnDtl grnDtl);
	
	//screen#2
	public List<GrnDtl> getAllGrnDtlsByGrnId(Integer grnId);
	public Integer updateGrnDtlStatus(Integer grnDtlId,String grnDtlStatus);
}
